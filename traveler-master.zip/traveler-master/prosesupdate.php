<?php
   include 'koneksi.php';
 $tujuan= $_POST['tujuan'];
 $nama= $_POST['nama'];
 $foto= $_POST['foto'];
 $waktu= $_POST['waktu'];
 $bandara= $_POST['bandara'];






  mysqli_query($dbconnect, "UPDATE `tb_produk` SET `tujuan`='$tujuan',`nama`='$nama',`foto`='$foto',`waktu`='$waktu',`bandara`='$bandara' ");

  header("location:index.php");
  ?>