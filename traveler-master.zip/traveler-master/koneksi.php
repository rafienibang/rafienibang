<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "tiketp";

$dbconnect = new mysqli("$host","$user","$pass","$db");





?>