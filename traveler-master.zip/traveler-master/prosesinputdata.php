<?php

   include 'koneksi.php';

 $tujuan= $_POST['tujuan'];
 $nama= $_POST['nama'];
 $foto= $_POST['foto'];
 $waktu= $_POST['waktu'];
 $bandara= $_POST['bandara'];
 






  mysqli_query($dbconnect, "INSERT INTO tb_produk VALUES (NULL,'$tujuan','$nama','$foto','$waktu','$bandara')");

  header("location:index.php");

  ?>